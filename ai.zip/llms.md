# rarelink-ig#2.0.0: RareLink Implementation Guide

## Pages

* [Home](index.md)
* [Downloads](downloads.md)
* [Artifacts Summary](artifacts.md)

## Resources

### ValueSets

* [Age at Diagnosis Value Set](ValueSet-age-at-diagnosis-vs.md)
* [Age at Onset Value Set](ValueSet-age-at-onset-vs.md)
* [Age Category Value Set](ValueSet-age-category-vs.md)
* [Age of Onset Value Set](ValueSet-age-of-onset-vs.md)
* [Agreement to Be Contacted Value Set (ERDRI-CDS)](ValueSet-agreement-to-be-contacted-vs.md)
* [Clinical Significance Value Set](ValueSet-clinical-significance-vs.md)
* [Consanguinity Value Set](ValueSet-consanguinity-vs.md)
* [Consent to Reuse Data Value Set (ERDRI-CDS)](ValueSet-consent-to-reuse-vs.md)
* [DNA Change Type Value Set](ValueSet-dna-change-type-vs.md)
* [Encounter Class Value Set](ValueSet-encounter-class-vs.md)
* [Family Relationship Value Set](ValueSet-family-relationship-vs.md)
* [Family Member Sex Value Set](ValueSet-family-sex-vs.md)
* [Genomic Source Class Value Set](ValueSet-genomic-source-class-vs.md)
* [Karyotypic Sex Value Set](ValueSet-karyotypic-sex-vs.md)
* [Level of Evidence Value Set](ValueSet-level-of-evidence-vs.md)
* [Phenotype Severity Value Set](ValueSet-phenotype-severity-vs.md)
* [Phenotype Status Value Set](ValueSet-phenotype-status-vs.md)
* [Propositus Value Set](ValueSet-propositus-vs.md)
* [Reference Genome Value Set](ValueSet-reference-genome-vs.md)
* [Severity Value Set](ValueSet-severity-vs.md)
* [Sex at Birth Value Set](ValueSet-sex-at-birth-vs.md)
* [Structural Variant Method Value Set](ValueSet-structural-variant-method-vs.md)
* [Temporal Pattern Value Set](ValueSet-temporal-pattern-vs.md)
* [Undiagnosed Rare Disease Case Value Set](ValueSet-undiagnosed-rd-case-vs.md)
* [Vital Status Value Set](ValueSet-vital-status-vs.md)
* [Zygosity Value Set](ValueSet-zygosity-vs.md)

### Resource Profiles

* [RareLink Condition for Undiagnosed RD Case](StructureDefinition-rarelink-condition-undiagnosed-rd-case.md)
* [RareLink Consent](StructureDefinition-rarelink-consent.md)
* [RareLink Diagnostic Implication Observation](StructureDefinition-rarelink-diagnostic-implication.md)
* [RareLink Encounter](StructureDefinition-rarelink-encounter.md)
* [RareLink Family History](StructureDefinition-rarelink-familyhistory.md)
* [RareLink Genetic Variant Observation](StructureDefinition-rarelink-genetic-variant.md)
* [RareLink IPS Condition](StructureDefinition-rarelink-ips-condition.md)
* [RareLink IPS Measurement Laboratory](StructureDefinition-rarelink-ips-measurement-laboratory.md)
* [RareLink IPS Measurement Radiology](StructureDefinition-rarelink-ips-measurement-radiology.md)
* [RareLink IPS Patient](StructureDefinition-rarelink-ips-patient.md)
* [RareLink IPS Procedure](StructureDefinition-rarelink-ips-procedure.md)
* [RareLink Observation Karyotypic Sex](StructureDefinition-rarelink-karyotypic-sex.md)
* [RareLink Observation Age Category](StructureDefinition-rarelink-observation-age-category.md)
* [RareLink Observation Gestation at Birth](StructureDefinition-rarelink-observation-gestation-at-birth.md)
* [RareLink Observation Measurements (Others)](StructureDefinition-rarelink-observation-measurements-others.md)
* [RareLink Vital Signs Measurements](StructureDefinition-rarelink-observation-vital-signs.md)
* [RareLink Observation Phenotypic Feature](StructureDefinition-rarelink-phenotypic-feature.md)

### Extensions

* [Age at Diagnosis](StructureDefinition-age-at-diagnosis.md)
* [Age at Onset](StructureDefinition-age-at-onset.md)
* [Birth Place](StructureDefinition-birth-place.md)
* [Cause of Death Code](StructureDefinition-cause-of-death-code.md)
* [Cause of Death Definition](StructureDefinition-cause-of-death-definition.md)
* [Cause of Death](StructureDefinition-cause-of-death.md)
* [Phenotype Causing Organism](StructureDefinition-causing-agent.md)
* [Clinical Modifier](StructureDefinition-clinical-modifier-1.md)
* [Clinical Modifier](StructureDefinition-clinical-modifier-2.md)
* [Clinical Modifier](StructureDefinition-clinical-modifier-3.md)
* [Consanguinity](StructureDefinition-consanguinity.md)
* [Date of Admission](StructureDefinition-date-of-admission.md)
* [Agreement to Be Contacted](StructureDefinition-erdri-agreement-to-be-contacted.md)
* [Consent to Reuse Data](StructureDefinition-erdri-consent-to-reuse-data.md)
* [Phenotype Severity](StructureDefinition-phenotype-severity.md)
* [Phenotype Status](StructureDefinition-phenotype-status.md)
* [Propositus](StructureDefinition-propositus.md)
* [Recorded Sex at Birth](StructureDefinition-recorded-sex-at-birth.md)
* [Resolution Date](StructureDefinition-resolution-date.md)
* [Phenotype Temporal Pattern](StructureDefinition-temporal-pattern.md)
* [Vital Status](StructureDefinition-vital-status.md)

### ImplementationGuides

* [RareLink Implementation Guide](index.md)
