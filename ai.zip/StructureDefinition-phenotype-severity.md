# Phenotype Severity - RareLink Implementation Guide v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Phenotype Severity**

## Extension: Phenotype Severity 

| | |
| :--- | :--- |
| *Official URL*:https://rarelink.bih-charite.de/fhir/StructureDefinition/phenotype-severity | *Version*:2.0.0 |
| Draft as of 2026-08-01 | *Computable Name*:PhenotypeSeverity |

The severity of the phenotypic feature.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [RareLink Observation Phenotypic Feature](StructureDefinition-rarelink-phenotypic-feature.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/rarelink-ig|current/StructureDefinition/StructureDefinition-phenotype-severity.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-phenotype-severity.csv), [Excel](StructureDefinition-phenotype-severity.xlsx), [Schematron](StructureDefinition-phenotype-severity.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "phenotype-severity",
  "url" : "https://rarelink.bih-charite.de/fhir/StructureDefinition/phenotype-severity",
  "version" : "2.0.0",
  "name" : "PhenotypeSeverity",
  "title" : "Phenotype Severity",
  "status" : "draft",
  "date" : "2026-08-01T16:27:48+00:00",
  "publisher" : "Berlin Institute of Health - Charité Universitätsmedizin Berlin",
  "contact" : [{
    "name" : "Berlin Institute of Health - Charité Universitätsmedizin Berlin",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/BIH-CEI/RareLink"
    },
    {
      "system" : "email",
      "value" : "adam.graefe@charite.de"
    }]
  }],
  "description" : "The severity of the phenotypic feature.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Phenotype Severity",
      "definition" : "The severity of the phenotypic feature."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://rarelink.bih-charite.de/fhir/StructureDefinition/phenotype-severity"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Extension.value[x].coding",
      "path" : "Extension.value[x].coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Extension.value[x].coding.system",
      "path" : "Extension.value[x].coding.system",
      "patternUri" : "http://purl.obolibrary.org/obo/hp.owl"
    },
    {
      "id" : "Extension.value[x].coding.code",
      "path" : "Extension.value[x].coding.code",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://rarelink.bih-charite.de/fhir/ValueSet/phenotype-severity-vs"
      }
    }]
  }
}

```
