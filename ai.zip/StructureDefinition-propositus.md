# Propositus - RareLink Implementation Guide v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Propositus**

## Extension: Propositus 

| | |
| :--- | :--- |
| *Official URL*:https://rarelink.bih-charite.de/fhir/StructureDefinition/propositus | *Version*:2.0.0 |
| Draft as of 2026-08-01 | *Computable Name*:Propositus |

Indicates whether the family member is the propositus.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [RareLink Family History](StructureDefinition-rarelink-familyhistory.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/rarelink-ig|current/StructureDefinition/StructureDefinition-propositus.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-propositus.csv), [Excel](StructureDefinition-propositus.xlsx), [Schematron](StructureDefinition-propositus.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "propositus",
  "url" : "https://rarelink.bih-charite.de/fhir/StructureDefinition/propositus",
  "version" : "2.0.0",
  "name" : "Propositus",
  "title" : "Propositus",
  "status" : "draft",
  "date" : "2026-08-01T16:27:48+00:00",
  "publisher" : "Berlin Institute of Health - Charité Universitätsmedizin Berlin",
  "contact" : [{
    "name" : "Berlin Institute of Health - Charité Universitätsmedizin Berlin",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/BIH-CEI/RareLink"
    },
    {
      "system" : "email",
      "value" : "adam.graefe@charite.de"
    }]
  }],
  "description" : "Indicates whether the family member is the propositus.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Propositus",
      "definition" : "Indicates whether the family member is the propositus."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://rarelink.bih-charite.de/fhir/StructureDefinition/propositus"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Extension.value[x].coding",
      "path" : "Extension.value[x].coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Extension.value[x].coding.system",
      "path" : "Extension.value[x].coding.system",
      "patternUri" : "http://snomed.info/sct"
    },
    {
      "id" : "Extension.value[x].coding.code",
      "path" : "Extension.value[x].coding.code",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://rarelink.bih-charite.de/fhir/ValueSet/propositus-vs"
      }
    }]
  }
}

```
