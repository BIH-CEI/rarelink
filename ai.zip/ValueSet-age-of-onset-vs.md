# Age of Onset Value Set - RareLink Implementation Guide v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Age of Onset Value Set**

## ValueSet: Age of Onset Value Set 

| | |
| :--- | :--- |
| *Official URL*:https://rarelink.bih-charite.de/fhir/ValueSet/age-of-onset-vs | *Version*:2.0.0 |
| Draft as of 2026-08-01 | *Computable Name*:AgeOfOnsetVS |

 
Value set for capturing the age of onset for phenotypes. 

 **References** 

* [RareLink Observation Phenotypic Feature](StructureDefinition-rarelink-phenotypic-feature.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "age-of-onset-vs",
  "url" : "https://rarelink.bih-charite.de/fhir/ValueSet/age-of-onset-vs",
  "version" : "2.0.0",
  "name" : "AgeOfOnsetVS",
  "title" : "Age of Onset Value Set",
  "status" : "draft",
  "date" : "2026-08-01T16:27:48+00:00",
  "publisher" : "Berlin Institute of Health - Charité Universitätsmedizin Berlin",
  "contact" : [{
    "name" : "Berlin Institute of Health - Charité Universitätsmedizin Berlin",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/BIH-CEI/RareLink"
    },
    {
      "system" : "email",
      "value" : "adam.graefe@charite.de"
    }]
  }],
  "description" : "Value set for capturing the age of onset for phenotypes.",
  "compose" : {
    "include" : [{
      "system" : "http://purl.obolibrary.org/obo/hp.owl",
      "concept" : [{
        "code" : "HP:0011460",
        "display" : "Embryonal onset (0w-8w embryonal)"
      },
      {
        "code" : "HP:0011461",
        "display" : "Fetal onset (8w embryonal - birth)"
      },
      {
        "code" : "HP:0003577",
        "display" : "Congenital onset (at birth)"
      },
      {
        "code" : "HP:0003623",
        "display" : "Neonatal onset (0d-28d)"
      },
      {
        "code" : "HP:0003593",
        "display" : "Infantile onset (28d-1y)"
      },
      {
        "code" : "HP:0011463",
        "display" : "Childhood onset (1y-5y)"
      },
      {
        "code" : "HP:0003621",
        "display" : "Juvenile onset (5y-15y)"
      },
      {
        "code" : "HP:0011462",
        "display" : "Young adult onset (16y-40y)"
      },
      {
        "code" : "HP:0003596",
        "display" : "Middle age adult onset (40y-60y)"
      },
      {
        "code" : "HP:0003584",
        "display" : "Late adult onset (60y+)"
      }]
    }]
  }
}

```
